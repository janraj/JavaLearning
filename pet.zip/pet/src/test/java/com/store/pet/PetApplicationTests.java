package com.store.pet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetApplicationTests {

	@Test
	void contextLoads() {
	}

}
