package com.Course.CourseAppv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseAppv2Application {

	public static void main(String[] args) {
		SpringApplication.run(CourseAppv2Application.class, args);
	}

}
